import { libWrapper } from "./lib/libWrapper/shim.js";

const MODULE_NAME = "skill"

console.log("foobar")